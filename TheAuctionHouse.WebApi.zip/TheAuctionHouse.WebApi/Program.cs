

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using TheAuctionHouse.Common;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Data.EFCore.SQLite;
using TheAuctionHouse.Domain.ServiceContracts;
using TheAuctionHouse.Domain.Services;

var builder = WebApplication.CreateBuilder(args);

// 🔐 Load JWT secret key from config
var jwtKey = builder.Configuration["Jwt:SecretKey"]
    ?? throw new InvalidOperationException("JWT secret key is missing in configuration.");
var key = Encoding.ASCII.GetBytes(jwtKey);

// 🔧 Configure EF Core with SQLite
builder.Services.AddDbContext<SQLiteAppDbContext>(options =>
    options.UseSqlite(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        x => x.MigrationsAssembly("TheAuctionHouse.Data.EFCore.SQLite")
    ));

// ✅ Register Unit of Work and Repositories
builder.Services.AddScoped<SQLiteAppDbContext>();
builder.Services.AddScoped<IAppUnitOfWork, SQLiteAppUnitOfWork>();

// ✅ Register domain services
builder.Services.AddScoped<IPortalUserService, PortalUserService>();
builder.Services.AddScoped<IAssetService, AssetService>();
builder.Services.AddScoped<IAuctionService, AuctionService>();
builder.Services.AddScoped<IWalletService, WalletService>();

// ✅ Supporting services
builder.Services.AddSingleton<IEmailService, EmailService>();
builder.Services.AddSingleton<IJwtTokenService>(new JwtTokenService(jwtKey));

// 🔐 Configure JWT authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// ========== AUTHENTICATION ENDPOINTS ==========
var authGroup = app.MapGroup("/auth");
authGroup.MapPost("/signup", async (SignUpRequest request, IPortalUserService userService) =>
{
    var result = await userService.SignUpAsync(request);
    return result.IsSuccess ? Results.Ok("Signup successful") : Results.BadRequest(result.Error.Message);
});

authGroup.MapPost("/login", async (LoginRequest request, IPortalUserService userService) =>
{
    var result = await userService.LoginAsync(request);
    return result.IsSuccess ? Results.Ok(new { token = result.Value }) : Results.BadRequest(result.Error.Message);
});

// Add these new endpoints:
authGroup.MapPost("/forgot-password", async (ForgotPasswordRequest request, IPortalUserService userService) =>
{
    var result = await userService.ForgotPasswordAsync(request);
    return result.IsSuccess 
        ? Results.Ok("If the email exists, a password reset link has been sent") 
        : Results.BadRequest(result.Error.Message);
}).AllowAnonymous(); // Doesn't require authentication

authGroup.MapPost("/reset-password", async (ResetPasswordRequest request, IPortalUserService userService) =>
{
    var result = await userService.ResetPasswordAsync(request);
    return result.IsSuccess 
        ? Results.Ok("Password reset successful") 
        : Results.BadRequest(result.Error.Message);
}).RequireAuthorization(); // Requires valid JWT

// ========== ASSET ENDPOINTS ==========
var assetGroup = app.MapGroup("/assets").RequireAuthorization();
assetGroup.MapPost("/", async (
    AssetInformationUpdateRequest request,
    IAssetService assetService,
    HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var result = await assetService.CreateAssetAsync(request);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

assetGroup.MapPut("/{id}", async (
    int id,
    AssetInformationUpdateRequest request,
    IAssetService assetService,
    HttpContext httpContext) =>  // Add HttpContext parameter
{
    Thread.CurrentPrincipal = httpContext.User;  // Set the principal like other endpoints
    var result = await assetService.UpdateAssetAsync(request);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
}); 

assetGroup.MapDelete("/{id}", async (int id, IAssetService assetService) =>
{
    var result = await assetService.DeleteAssetAsync(id);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

assetGroup.MapGet("/", async (IAssetService assetService, HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var userId = int.Parse(httpContext.User.FindFirst("userId")?.Value ?? "0");
    var result = await assetService.GetAllAssetsByUserIdAsync(userId);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

assetGroup.MapGet("/{id}", async (int id, IAssetService assetService) =>
{
    var result = await assetService.GetAssetByIdAsync(id);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

// ========== AUCTION ENDPOINTS ==========
var auctionGroup = app.MapGroup("/auctions").RequireAuthorization();
auctionGroup.MapPost("/", async (
    PostAuctionRequest request,
    IAuctionService auctionService,
    HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var result = await auctionService.PostAuctionAsync(request);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

auctionGroup.MapGet("/", async (IAuctionService auctionService) =>
{
    var result = await auctionService.GetAllOpenAuctionsByUserIdAsync();
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

auctionGroup.MapGet("/my", async (IAuctionService auctionService, HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var userId = int.Parse(httpContext.User.FindFirst("userId")?.Value ?? "0");
    var result = await auctionService.GetAuctionsByUserIdAsync(userId);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

assetGroup.MapPost("/{id}/status/{newStatus}", async (
    int id, 
    string newStatus,
    IAssetService assetService,
    HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var result = await assetService.ChangeAssetStatusAsync(id, newStatus);
    return result.IsSuccess ? Results.Ok() : Results.BadRequest(result.Error.Message);
}).RequireAuthorization();

// ========== WALLET ENDPOINTS ==========
var walletGroup = app.MapGroup("/wallet").RequireAuthorization();
walletGroup.MapPost("/deposit", async (
    WalletTransactionRequest request,
    IWalletService walletService,
    HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var result = await walletService.DepositAsync(request);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

walletGroup.MapPost("/withdraw", async (
    WalletTransactionRequest request,
    IWalletService walletService,
    HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var result = await walletService.WithDrawalAsync(request);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

walletGroup.MapGet("/balance", async (IWalletService walletService, HttpContext httpContext) =>
{
    Thread.CurrentPrincipal = httpContext.User;
    var userId = int.Parse(httpContext.User.FindFirst("userId")?.Value ?? "0");
    var result = await walletService.GetWalletBalenceAsync(userId);
    return result.IsSuccess ? Results.Ok(result.Value) : Results.BadRequest(result.Error.Message);
});

app.Run();
