using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;

public class InMemoryAuctionRepository : GenericRepository<Auction>, IAuctionRepository
{
    public InMemoryAuctionRepository(IAppDbContext context) : base(context) { }

    public async Task<List<Auction>> GetAuctionsByUserIdAsync(int userId)
    {
        return await _context.Auctions
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.StartDate)
            .ToListAsync();
    }

    public async Task<List<BidHistory>> GetBidHistoriesByUserIdAsync(int userId)
    {
        return await _context.BidHistories
            .Where(b => b.BidderId == userId)
            .OrderByDescending(b => b.BidDate)
            .ToListAsync();
    }

    public async Task<List<BidHistory>> GetBidHistoriesByAuctionIdAsync(int auctionId)
    {
        return await _context.BidHistories
            .Where(b => b.AuctionId == auctionId)
            .OrderByDescending(b => b.BidAmount)
            .ThenBy(b => b.BidDate)
            .ToListAsync();
    }
}