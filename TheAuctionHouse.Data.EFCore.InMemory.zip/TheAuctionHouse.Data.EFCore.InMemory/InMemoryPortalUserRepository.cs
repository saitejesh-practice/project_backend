using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;

public class InMemoryPortalUserRepository : GenericRepository<PortalUser>, IPortalUserRepository
{
    public InMemoryPortalUserRepository(IAppDbContext context) : base(context) { }

    public async Task<PortalUser?> GetUserByEmailAsync(string email)
    {
        return await _context.PortalUsers
            .FirstOrDefaultAsync(u => u.EmailId == email);
    }

    public async Task<PortalUser?> GetUserByUserIdAsync(int userId)
    {
        return await _context.PortalUsers
            .FirstOrDefaultAsync(u => u.Id == userId);
    }

    public void DepositWalletBalance(int userId, int amount)
    {
        var user = _context.PortalUsers.FirstOrDefault(u => u.Id == userId);
        if (user != null)
        {
            user.WalletBalence += amount;
            _context.SaveChanges();
        }
    }

    public void WithdrawWalletBalance(int userId, int amount)
    {
        var user = _context.PortalUsers.FirstOrDefault(u => u.Id == userId);
        if (user != null && (user.WalletBalence - user.WalletBalenceBlocked) >= amount)
        {
            user.WalletBalence -= amount;
            _context.SaveChanges();
        }
    }
}