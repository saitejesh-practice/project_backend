using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;

public class InMemoryAssetRepository : GenericRepository<Asset>, IAssetRepository
{
    public InMemoryAssetRepository(IAppDbContext context) : base(context) { }

    public async Task<List<Asset>> GetAssetsByUserIdAsync(int userId)
    {
        return await _context.Assets
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.Id)
            .ToListAsync();
    }
}