﻿// using Microsoft.EntityFrameworkCore;
// using TheAuctionHouse.Data.EFCore.InMemory;
// using TheAuctionHouse.Domain.ServiceContracts;
// using TheAuctionHouse.Domain.Entities;
// using TheAuctionHouse.Domain.Services;

// // See https://aka.ms/new-console-template for more information
// Console.WriteLine("Hello, World!");

// var builder = WebApplication.CreateBuilder(args);

// // Register your DbContext with InMemory provider
// builder.Services.AddDbContext<InMemoryAppDbContext>(options =>
//     options.UseInMemoryDatabase("AuctionHouseDb"));


// // Register your DbContext as IAppDbContext for DI
// builder.Services.AddScoped<IAppDbContext>(provider => provider.GetRequiredService<InMemoryAppDbContext>());



// // builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();


// builder.Services.AddScoped<IJwtTokenService>(provider =>
//     new JwtTokenService(
//         "b7e3f8a2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0", // secret
//         "TheAuctionHouse", // issuer
//         "TheAuctionHouseUsers" // audience
//     )
// );

// builder.Services.AddScoped<IEmailService, EmailService>();

// builder.Services.AddScoped<IAppUnitOfWork, InMemoryAppUnitOfWork>();

// builder.Services.AddScoped<IPortalUserService, PortalUserService>();
// // Register your services, repositories, etc.
// // builder.Services.AddScoped<IPortalUserService, PortalUserService>();

// // JWT Authentication configuration
// builder.Services.AddAuthentication("Bearer")
//     .AddJwtBearer("Bearer", options =>
//     {
//         options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
//         {
//             ValidateIssuer = true,
//             ValidateAudience = true,
//             ValidateLifetime = true,
//             ValidateIssuerSigningKey = true,
//             ValidIssuer = "TheAuctionHouse",
//             ValidAudience = "TheAuctionHouseUsers",
//             IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
//                 System.Text.Encoding.UTF8.GetBytes("b7e3f8a2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0"))
//         };
//     });

// builder.Services.AddControllers();

// var app = builder.Build();

// // using (var scope = app.Services.CreateScope())
// // {
// //     var db = scope.ServiceProvider.GetRequiredService<InMemoryAppDbContext>();
// //     db.PortalUsers.Add(new PortalUser { EmailId = "test@example.com", HashedPassword = "password", Name = "Test User" });
// //     db.SaveChanges();
// // }

// app.UseAuthentication();
// app.UseAuthorization();

// app.MapControllers();

// app.Run();


using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.SQLite;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using TheAuctionHouse.Domain.Services;

// Initialize SQLite database
var options = new DbContextOptionsBuilder<SQLiteAppDbContext>()
    .UseSqlite("Data Source=./Data/TheAuctionHouse.db")
    .Options;

using var context = new SQLiteAppDbContext(options);
context.Database.EnsureCreated(); // Creates DB if not exists

// Initialize dependencies
var unitOfWork = new SQLiteAppUnitOfWork(context);

// Mock services for console testing
var mockEmailService = new MockEmailService();
var mockJwtTokenService = new MockJwtTokenService();

// Initialize services
var assetService = new AssetService(unitOfWork);
var auctionService = new AuctionService(unitOfWork);
var userService = new PortalUserService(unitOfWork, mockEmailService, mockJwtTokenService);
var walletService = new WalletService(unitOfWork);

// ===== TEST SCENARIOS ===== //

// 1. Test user registration
var signUpResult = await userService.SignUpAsync(new SignUpRequest
{
    Name = "Console Test User",
    EmailId = "console@test.com",
    Password = "Test@123"
});

Console.WriteLine(signUpResult.IsSuccess
    ? $"User registered successfully! (ID: {signUpResult.Value})"
    : $"Error: {signUpResult.Error.Message}");

// 2. Test asset creation
var assetResult = await assetService.CreateAssetAsync(new AssetInformationUpdateRequest
{
    Title = "Console Test Asset",
    Description = "Created via console app",
    RetailPrice = 5000
});

Console.WriteLine(assetResult.IsSuccess
    ? $"Asset created successfully! (ID: {assetResult.Value})"
    : $"Error: {assetResult.Error.Message}");

// 3. Test wallet deposit
var depositResult = await walletService.DepositAsync(new WalletTransactionRequest
{
    UserId = 1, // Assuming user ID 1 exists
    Amount = 10000
});

Console.WriteLine(depositResult.IsSuccess
    ? "Wallet deposit successful!"
    : $"Error: {depositResult.Error.Message}");

// ===== MOCK SERVICE IMPLEMENTATIONS ===== //

public class MockEmailService : IEmailService
{
    public Task SendEmailAsync(string to, string subject, string body, bool isHtml = true)
    {
        Console.WriteLine($"Mock Email Sent to: {to}");
        Console.WriteLine($"Subject: {subject}");
        Console.WriteLine($"Body: {body}");
        return Task.CompletedTask;
    }
}

public class MockJwtTokenService : IJwtTokenService
{
    public string GenerateToken(int userId, string email)
    {
        Console.WriteLine($"Mock Token Generated for: {email} (ID: {userId})");
        return "mock-jwt-token";
    }
}