﻿using System.Threading.Tasks;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Common.Validation;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;

namespace TheAuctionHouse.Domain.Services;

public class PortalUserService : IPortalUserService
{
    private readonly IAppUnitOfWork _appUnitOfWork;
    private readonly IEmailService _emailService;
    private readonly IJwtTokenService _jwtTokenService; // Add JWT service dependency

    public PortalUserService(IAppUnitOfWork appUnitOfWork, IEmailService emailService, IJwtTokenService jwtTokenService)
    {
        _appUnitOfWork = appUnitOfWork;
        _emailService = emailService;
        _jwtTokenService = jwtTokenService; // Initialize JWT service

    }
    public async Task<Result<bool>> LogoutAsync(int userId)
    {
        try
        {
            // Validate user ID
            if (userId <= 0)
            {
                return Error.BadRequest("Invalid user ID");
            }

            // Validate user exists
            var user = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(userId);
            if (user == null)
            {
                return Error.NotFound("User not found");
            }

            // Additional validation could include:
            // - Checking if user is already logged out
            // - Validating session status

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }
    // public async Task<Result<bool>> ForgotPasswordAsync(ForgotPasswordRequest forgotPasswordRequest)
    // {
    //     try
    //     {
    //         //Check if the email id is not null or empty.
    //         //validate if the email address is in the expected format.
    //         Error validationError = Error.ValidationFailures();
    //         if (!ValidationHelper.Validate(forgotPasswordRequest, validationError))
    //         {
    //             return validationError;
    //         }
    //         //Check if the email id exists.
    //         PortalUser? portalUser = await _appUnitOfWork.PortalUserRepository.GetUserByEmailAsync(forgotPasswordRequest.EmailId);

    //         if (portalUser == null)
    //             return Error.NotFound("User Not Found.");

    //         //Send a reset password link to the email id.
    //         //await _emailService.SendEmailAsync(portalUser.EmailId, "Password Reset | The Auction House", $"Dear {portalUser.Name}, \n <a href=\"https://TheAuctionHouse/ResetPassword\" click here to reset the password. \n Regards Admin Team", true);
    //         await _emailService.SendEmailAsync(portalUser.EmailId, "Password Reset | The Auction House", $"", true);
    //         return true;
    //     }
    //     catch (Exception ex)
    //     {
    //         return Error.InternalServerError(ex.Message);
    //     }
    // }

    public async Task<Result<bool>> ForgotPasswordAsync(ForgotPasswordRequest forgotPasswordRequest)
    {
        try
        {
            // Validate email format
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(forgotPasswordRequest, validationError))
                return validationError;

            // Check if user exists (READ only)
            var user = await _appUnitOfWork.PortalUserRepository.GetUserByEmailAsync(forgotPasswordRequest.EmailId);

            // Even if user doesn't exist, return success (security best practice)
            if (user != null)
            {
                // Send email (no DB changes)
                await _emailService.SendEmailAsync(
                    user.EmailId,
                    "Password Reset",
                    "Click here to reset your password: [LINK]",
                    true);
            }

            return true; // Always return success to avoid email enumeration attacks
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<bool>> SignUpAsync(SignUpRequest signUpRequest)
    {
        try
        {
            // Manual validation for required fields
            if (string.IsNullOrWhiteSpace(signUpRequest.Name))
                return Error.ValidationFailures();

            if (string.IsNullOrWhiteSpace(signUpRequest.EmailId))
                return Error.ValidationFailures();

            if (string.IsNullOrWhiteSpace(signUpRequest.Password))
                return Error.ValidationFailures();

            // Optionally, add a simple email format check
            if (!signUpRequest.EmailId.Contains("@") || !signUpRequest.EmailId.Contains("."))
                return Error.ValidationFailures();

            // Optionally, check password length
            if (signUpRequest.Password.Length < 6)
                return Error.ValidationFailures();

            // Validate request
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(signUpRequest, validationError))
            {
                return validationError;
            }

            // Check if email already exists
            var existingUser = await _appUnitOfWork.PortalUserRepository.GetUserByEmailAsync(signUpRequest.EmailId);
            if (existingUser != null)
            {
                return Error.BadRequest("Email already registered");
            }

            // Create new user
            var newUser = new PortalUser
            {
                Name = signUpRequest.Name,
                EmailId = signUpRequest.EmailId,
                HashedPassword = HashPassword(signUpRequest.Password), // Implement password hashing
                WalletBalence = 0,
                WalletBalenceBlocked = 0
            };

            await _appUnitOfWork.PortalUserRepository.AddAsync(newUser);
            await _appUnitOfWork.SaveChangesAsync();

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<string>> LoginAsync(LoginRequest loginRequest)
    {
        try
        {
            // Validate request
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(loginRequest, validationError))
            {
                return validationError;
            }
            // Manual validation for required fields
            if (string.IsNullOrWhiteSpace(loginRequest.EmailId))
                return Error.ValidationFailures();
            if (string.IsNullOrWhiteSpace(loginRequest.Password))
                return Error.ValidationFailures();



            // Find user by email
            var user = await _appUnitOfWork.PortalUserRepository.GetUserByEmailAsync(loginRequest.EmailId);
            if (user == null)
            {
                return Error.NotFound("User not found");
            }

            // Verify password
            if (!VerifyPassword(loginRequest.Password, user.HashedPassword))
            {
                return Error.BadRequest("Invalid credentials");
            }

            // // In a real app, we'd generate a token here
            // return true;
            var token = _jwtTokenService.GenerateToken(user.Id, user.EmailId);

            return token;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    // In PortalUserService.cs
    // public async Task<Result<bool>> ResetPasswordAsync(ResetPasswordRequest resetPasswordRequest)
    // {
    //     try
    //     {
    //         // Manual validation for required fields
    //         if (resetPasswordRequest.UserId <= 0 ||
    //             string.IsNullOrWhiteSpace(resetPasswordRequest.OldPassword) ||
    //             string.IsNullOrWhiteSpace(resetPasswordRequest.NewPassword) ||
    //             string.IsNullOrWhiteSpace(resetPasswordRequest.ConfirmPassword))
    //         {
    //             return Error.ValidationFailures();
    //         }

    //         // Validate request
    //         Error validationError = Error.ValidationFailures();
    //         if (!ValidationHelper.Validate(resetPasswordRequest, validationError))
    //         {
    //             return validationError;
    //         }

    //         // Get user by ID (from authenticated context)
    //         var user = await _appUnitOfWork.PortalUserRepository
    //             .GetUserByUserIdAsync(resetPasswordRequest.UserId);

    //         if (user == null)
    //         {
    //             return Error.NotFound("User not found");
    //         }

    //         // Verify old password matches
    //         if (!VerifyPassword(resetPasswordRequest.OldPassword, user.HashedPassword))
    //         {
    //             return Error.BadRequest("Current password is incorrect");
    //         }

    //         // Verify new passwords match
    //         if (resetPasswordRequest.NewPassword != resetPasswordRequest.ConfirmPassword)
    //         {
    //             return Error.BadRequest("New passwords don't match");
    //         }

    //         // Update password
    //         user.HashedPassword = HashPassword(resetPasswordRequest.NewPassword);
    //         await _appUnitOfWork.PortalUserRepository.UpdateAsync(user);
    //         await _appUnitOfWork.SaveChangesAsync();

    //         return true;
    //     }
    //     catch (Exception ex)
    //     {
    //         return Error.InternalServerError(ex.Message);
    //     }
    // }


    public async Task<Result<bool>> ResetPasswordAsync(ResetPasswordRequest resetPasswordRequest)
{
    try
    {
        // Validate input
        Error validationError = Error.ValidationFailures();
        if (!ValidationHelper.Validate(resetPasswordRequest, validationError))
            return validationError;

        // Fetch user (READ)
        var user = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(resetPasswordRequest.UserId);
        if (user == null)
            return Error.NotFound("User not found");

        // Verify old password
        if (!VerifyPassword(resetPasswordRequest.OldPassword, user.HashedPassword))
            return Error.BadRequest("Current password is incorrect");

        // Update password (UPDATE)
        user.HashedPassword = HashPassword(resetPasswordRequest.NewPassword);
        await _appUnitOfWork.PortalUserRepository.UpdateAsync(user);
        await _appUnitOfWork.SaveChangesAsync();

        return true;
    }
    catch (Exception ex)
    {
        return Error.InternalServerError(ex.Message);
    }
}


    // Helper methods for password hashing
    // private string HashPassword(string password)
    // {
    //     // In a real app, use proper hashing like BCrypt or Argon2
    //     return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password));
    // }

    // private bool VerifyPassword(string password, string hashedPassword)
    // {
    //     return HashPassword(password) == hashedPassword;
    // }

    private string HashPassword(string password)
    {
        // Enhanced validation
        if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
        {
            throw new ArgumentException("Password must be at least 6 characters");
        }

        // In production, use: return BCrypt.Net.BCrypt.HashPassword(password);
        return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password));
    }

    private bool VerifyPassword(string password, string hashedPassword)
    {
        if (string.IsNullOrWhiteSpace(password))
        {
            throw new ArgumentException("Password cannot be empty");
        }

        if (string.IsNullOrWhiteSpace(hashedPassword))
        {
            throw new ArgumentException("Hashed password cannot be empty");
        }

        return HashPassword(password) == hashedPassword;
    }

}
