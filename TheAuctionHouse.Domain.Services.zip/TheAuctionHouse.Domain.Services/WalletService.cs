using System;
using System.Threading.Tasks;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Common.Validation;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;

namespace TheAuctionHouse.Domain.Services
{
    public class WalletService : IWalletService
    {
        private readonly IAppUnitOfWork _appUnitOfWork;

        public WalletService(IAppUnitOfWork appUnitOfWork)
        {
            _appUnitOfWork = appUnitOfWork;
        }

        public async Task<Result<bool>> DepositAsync(WalletTransactionRequest walletTransactionRequest)
        {
            try
            {
                // Validate input
                Error validationError = Error.ValidationFailures();
                if (!ValidationHelper.Validate(walletTransactionRequest, validationError))
                {
                    return validationError;
                }

                if (walletTransactionRequest.Amount <= 0)
                {
                    return Error.BadRequest("Amount must be greater than 0");
                }

                var user = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(walletTransactionRequest.UserId);
                if (user == null)
                {
                    return Error.NotFound("User not found");
                }

                user.WalletBalence += walletTransactionRequest.Amount;
                await _appUnitOfWork.PortalUserRepository.UpdateAsync(user);
                await _appUnitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                return Error.InternalServerError(ex.Message);
            }
        }

        public async Task<Result<bool>> WithDrawalAsync(WalletTransactionRequest walletTransactionRequest)
        {
            try
            {
                // Validate input
                var validationError = Error.ValidationFailures();
                if (!ValidationHelper.Validate(walletTransactionRequest, validationError))
                {
                    return validationError;
                }

                if (walletTransactionRequest.Amount <= 0)
                {
                    return Error.BadRequest("Amount must be greater than 0");
                }

                var user = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(walletTransactionRequest.UserId);
                if (user == null)
                {
                    return Error.NotFound("User not found");
                }

                if (user.WalletBalence < walletTransactionRequest.Amount)
                {
                    return Error.BadRequest("Insufficient wallet balance");
                }

                user.WalletBalence -= walletTransactionRequest.Amount;
                await _appUnitOfWork.PortalUserRepository.UpdateAsync(user);
                await _appUnitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                return Error.InternalServerError(ex.Message);
            }
        }

        public async Task<Result<WalletBalenceResponse>> GetWalletBalenceAsync(int userId)
        {
            try
            {
                if (userId <= 0)
                {
                    return Error.BadRequest("Invalid user ID");
                }

                var user = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(userId);
                if (user == null)
                {
                    return Error.NotFound("User not found");
                }

                var response = new WalletBalenceResponse
                {
                    UserId = user.Id,
                    Amount = user.WalletBalence,
                    BlockedAmount = user.WalletBalenceBlocked
                };

                return response;
            }
            catch (Exception ex)
            {
                return Error.InternalServerError(ex.Message);
            }
        }
    }
}
