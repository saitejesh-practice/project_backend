using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

public class JwtTokenService : IJwtTokenService
{
    private readonly string _secretKey;
    private readonly int _expiryHours;

    public JwtTokenService(string secretKey, int expiryHours = 1)
    {
        _secretKey = secretKey ?? throw new ArgumentNullException(nameof(secretKey));
        _expiryHours = expiryHours;
    }

    public string GenerateToken(int userId, string email)
    {
        if (string.IsNullOrEmpty(email))
            throw new ArgumentException("Email cannot be null or empty", nameof(email));

        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(_secretKey);

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Email, email),
                new Claim("userId", userId.ToString())
                // Add more claims as needed (e.g., roles)
            }),
            Expires = DateTime.UtcNow.AddHours(_expiryHours),
            SigningCredentials = new SigningCredentials(
                new SymmetricSecurityKey(key), 
                SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }
}