using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Common.Validation;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;

namespace TheAuctionHouse.Domain.Services;

public class AuctionService : IAuctionService
{
    private readonly IAppUnitOfWork _appUnitOfWork;
    private const int MaxReservePrice = 9999;
    private const int MaxBidIncrement = 999;
    private const int MaxExpiryMinutes = 10080; // 7 days

    public AuctionService(IAppUnitOfWork appUnitOfWork)
    {
        _appUnitOfWork = appUnitOfWork;
    }

    public async Task<Result<bool>> PostAuctionAsync(PostAuctionRequest request)
    {
        try
        {
            // Validate request data annotations
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(request, validationError))
            {
                return validationError;
            }

            // Business rule validations
            if (request.ReservedPrice <= 0 || request.ReservedPrice > MaxReservePrice)
            {
                return Error.BadRequest($"Reserve price must be between 1-{MaxReservePrice}");
            }

            if (request.MinimumBidIncrement <= 0 || request.MinimumBidIncrement > MaxBidIncrement)
            {
                return Error.BadRequest($"Minimum bid increment must be between 1-{MaxBidIncrement}");
            }

            if (request.TotalMinutesToExpiry <= 0 || request.TotalMinutesToExpiry > MaxExpiryMinutes)
            {
                return Error.BadRequest($"Expiry time must be between 1-{MaxExpiryMinutes} minutes");
            }

            // Validate asset exists and belongs to user
            var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(request.AssetId);
            if (asset == null)
            {
                return Error.NotFound("Asset not found");
            }

            if (asset.UserId != request.OwnerId)
            {
                return Error.BadRequest("Asset does not belong to user");
            }

            if (asset.Status != AssetStatus.OpenToAuction)
            {
                return Error.BadRequest("Asset must be in OpenToAuction status");
            }

            // Create new auction
            var auction = new Auction
            {
                UserId = request.OwnerId,
                AssetId = request.AssetId,
                ReservedPrice = request.ReservedPrice,
                CurrentHighestBid = 0,
                CurrentHighestBidderId = 0,
                MinimumBidIncrement = request.MinimumBidIncrement,
                StartDate = DateTime.UtcNow,
                TotalMinutesToExpiry = request.TotalMinutesToExpiry,
                Status = AuctionStatus.Live
            };

            // Update asset status
            asset.Status = AssetStatus.ClosedForAuction;

            await _appUnitOfWork.AuctionRepository.AddAsync(auction);
            await _appUnitOfWork.AssetRepository.UpdateAsync(asset);
            await _appUnitOfWork.SaveChangesAsync();

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<bool>> CheckAuctionExpiriesAsync()
    {
        try
        {
            var liveAuctions = await _appUnitOfWork.AuctionRepository
                .FindAsync(a => a.Status == AuctionStatus.Live);

            if (!liveAuctions.Any())
            {
                return Error.NotFound("No live auctions found");
            }

            bool changesMade = false;

            foreach (var auction in liveAuctions)
            {
                if (!auction.IsExpired()) continue;

                changesMade = true;
                var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(auction.AssetId);

                if (auction.IsExpiredWithoutBids())
                {
                    // No bids - return asset to Open status
                    auction.Status = AuctionStatus.ExpiredWithoutBids;
                    if (asset != null)
                    {
                        asset.Status = AssetStatus.OpenToAuction;
                        await _appUnitOfWork.AssetRepository.UpdateAsync(asset);
                    }
                }
                else
                {
                    // Has bids - transfer ownership
                    auction.Status = AuctionStatus.Expired;
                    if (asset != null)
                    {
                        // Transfer ownership
                        asset.UserId = auction.CurrentHighestBidderId;
                        asset.Status = AssetStatus.OpenToAuction;
                        await _appUnitOfWork.AssetRepository.UpdateAsync(asset);

                        // Unblock bidder's wallet
                        var bidder = await _appUnitOfWork.PortalUserRepository
                            .GetUserByUserIdAsync(auction.CurrentHighestBidderId);
                        if (bidder != null)
                        {
                            bidder.WalletBalenceBlocked -= auction.CurrentHighestBid;
                            await _appUnitOfWork.PortalUserRepository.UpdateAsync(bidder);
                        }
                    }
                }
                await _appUnitOfWork.AuctionRepository.UpdateAsync(auction);
            }

            if (changesMade)
            {
                await _appUnitOfWork.SaveChangesAsync();
            }

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<AuctionResponse>> GetAuctionByIdAsync(int auctionId)
    {
        try
        {
            if (auctionId <= 0)
            {
                return Error.BadRequest("Invalid auction ID");
            }

            var auction = await _appUnitOfWork.AuctionRepository.GetByIdAsync(auctionId);
            if (auction == null)
            {
                return Error.NotFound("Auction not found");
            }

            var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(auction.AssetId);
            var highestBidder = auction.CurrentHighestBidderId > 0 
                ? await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(auction.CurrentHighestBidderId)
                : null;

            return new AuctionResponse
            {
                AuctionId = auction.Id,
                UserId = auction.UserId,
                AssetId = auction.AssetId,
                AssetTitle = asset?.Title ?? string.Empty,
                AssetDescription = asset?.Description ?? string.Empty,
                CurrentHighestBid = auction.CurrentHighestBid,
                CurrentHighestBidderId = auction.CurrentHighestBidderId,
                HighestBidderName = highestBidder?.Name ?? string.Empty,
                MinimumBidIncrement = auction.MinimumBidIncrement,
                StartDate = auction.StartDate,
                TotalMinutesToExpiry = auction.TotalMinutesToExpiry,
                Status = auction.Status.ToString()
            };
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<List<AuctionResponse>>> GetAuctionsByUserIdAsync(int userId)
    {
        try
        {
            if (userId <= 0)
            {
                return Error.BadRequest("Invalid user ID");
            }

            var userExists = await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(userId);
            if (userExists == null)
            {
                return Error.NotFound("User not found");
            }

            var auctions = await _appUnitOfWork.AuctionRepository.GetAuctionsByUserIdAsync(userId);
            
            if (!auctions.Any())
            {
                return Error.NotFound("No auctions found for this user");
            }

            return await MapAuctionsToResponses(auctions);
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<List<AuctionResponse>>> GetAllOpenAuctionsByUserIdAsync()
    {
        try
        {
            var auctions = await _appUnitOfWork.AuctionRepository
                .FindAsync(a => a.Status == AuctionStatus.Live);

            if (!auctions.Any())
            {
                return Error.NotFound("No open auctions found");
            }

            return await MapAuctionsToResponses(auctions);
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }
     


    private async Task<List<AuctionResponse>> MapAuctionsToResponses(IEnumerable<Auction> auctions)
    {
        var responses = new List<AuctionResponse>();

        foreach (var auction in auctions)
        {
            var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(auction.AssetId);
            var highestBidder = auction.CurrentHighestBidderId > 0
                ? await _appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(auction.CurrentHighestBidderId)
                : null;

            responses.Add(new AuctionResponse
            {
                AuctionId = auction.Id,
                UserId = auction.UserId,
                AssetId = auction.AssetId,
                AssetTitle = asset?.Title ?? string.Empty,
                AssetDescription = asset?.Description ?? string.Empty,
                CurrentHighestBid = auction.CurrentHighestBid,
                CurrentHighestBidderId = auction.CurrentHighestBidderId,
                HighestBidderName = highestBidder?.Name ?? string.Empty,
                MinimumBidIncrement = auction.MinimumBidIncrement,
                StartDate = auction.StartDate,
                TotalMinutesToExpiry = auction.TotalMinutesToExpiry,
                Status = auction.Status.ToString()
            });
        }

        return responses;
    }
}