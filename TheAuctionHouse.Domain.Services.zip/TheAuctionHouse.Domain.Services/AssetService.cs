// using TheAuctionHouse.Common.ErrorHandling;
// using TheAuctionHouse.Common.Validation;
// using TheAuctionHouse.Domain.Entities;
// using TheAuctionHouse.Domain.ServiceContracts;

// namespace TheAuctionHouse.Domain.Services;

// public class AssetService : IAssetService
// {
//     private readonly IAppUnitOfWork _appUnitOfWork;

//     public AssetService(IAppUnitOfWork appUnitOfWork)
//     {
//         _appUnitOfWork = appUnitOfWork;
//     }

//     public async Task<Result<bool>> CreateAssetAsync(AssetInformationUpdateRequest createAssetRequest)
//     {
//         try
//         {
//             // Validate request
//             Error validationError = Error.ValidationFailures();
//             if (!ValidationHelper.Validate(createAssetRequest, validationError))
//             {
//                 return validationError;
//             }

//             // Additional validation
//             if (createAssetRequest.Title.Length < 10 || createAssetRequest.Title.Length > 150)
//             {
//                 return Error.BadRequest("Title must be between 10-150 characters.");
//             }

//             if (createAssetRequest.Description.Length < 10 || createAssetRequest.Description.Length > 1000)
//             {
//                 return Error.BadRequest("Description must be between 10-1000 characters.");
//             }

//             if (createAssetRequest.RetailPrice <= 0)
//             {
//                 return Error.BadRequest("Retail price must be a positive value.");
//             }

//             // Create new asset
//             var newAsset = new Asset
//             {
//                 Title = createAssetRequest.Title.Trim(),
//                 Description = createAssetRequest.Description.Trim(),
//                 RetailValue = createAssetRequest.RetailPrice,
//                 Status = AssetStatus.Draft
//             };

//             await _appUnitOfWork.AssetRepository.AddAsync(newAsset);
//             await _appUnitOfWork.SaveChangesAsync();

//             return true;
//         }
//         catch (Exception ex)
//         {
//             return Error.InternalServerError(ex.Message);
//         }
//     }

//     public async Task<Result<bool>> UpdateAssetAsync(AssetInformationUpdateRequest updateAssetRequest)
//     {
//         try
//         {
//             // Validate request
//             Error validationError = Error.ValidationFailures();
//             if (!ValidationHelper.Validate(updateAssetRequest, validationError))
//             {
//                 return validationError;
//             }

//             // Get existing asset
//             var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(updateAssetRequest.RetailPrice);
//             if (asset == null)
//             {
//                 return Error.NotFound("Asset not found.");
//             }

//             // Check if asset is in draft status
//             if (asset.Status != AssetStatus.Draft)
//             {
//                 return Error.BadRequest("Only draft assets can be updated.");
//             }

//             // Additional validation
//             if (updateAssetRequest.Title.Length < 10 || updateAssetRequest.Title.Length > 150)
//             {
//                 return Error.BadRequest("Title must be between 10-150 characters.");
//             }

//             if (updateAssetRequest.Description.Length < 10 || updateAssetRequest.Description.Length > 1000)
//             {
//                 return Error.BadRequest("Description must be between 10-1000 characters.");
//             }

//             if (updateAssetRequest.RetailPrice <= 0)
//             {
//                 return Error.BadRequest("Retail price must be a positive value.");
//             }

//             // Update asset
//             asset.Title = updateAssetRequest.Title.Trim();
//             asset.Description = updateAssetRequest.Description.Trim();
//             asset.RetailValue = updateAssetRequest.RetailPrice;

//             await _appUnitOfWork.AssetRepository.UpdateAsync(asset);
//             await _appUnitOfWork.SaveChangesAsync();

//             return true;
//         }
//         catch (Exception ex)
//         {
//             return Error.InternalServerError(ex.Message);
//         }
//     }

//     public async Task<Result<bool>> DeleteAssetAsync(int assetId)
//     {
//         try
//         {
//             // Validate assetId
//             if (assetId <= 0)
//             {
//                 return Error.BadRequest("Asset ID must be a positive integer.");
//             }

//             var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(assetId);
//             if (asset == null)
//             {
//                 return Error.NotFound("Asset not found.");
//             }

//             // Check if asset is in draft or open status
//             if (asset.Status != AssetStatus.Draft && asset.Status != AssetStatus.OpenToAuction)
//             {
//                 return Error.BadRequest("Only draft or open assets can be deleted.");
//             }

//             await _appUnitOfWork.AssetRepository.DeleteAsync(asset);
//             await _appUnitOfWork.SaveChangesAsync();

//             return true;
//         }
//         catch (Exception ex)
//         {
//             return Error.InternalServerError(ex.Message);
//         }
//     }

//     public async Task<Result<AssetResponse>> GetAssetByIdAsync(int assetId)
//     {
//         try
//         {
//             // Validate assetId
//             if (assetId <= 0)
//             {
//                 return Error.BadRequest("Asset ID must be a positive integer.");
//             }

//             var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(assetId);
//             if (asset == null)
//             {
//                 return Error.NotFound("Asset not found.");
//             }

//             return new AssetResponse
//             {
//                 AssetId = asset.Id,
//                 Title = asset.Title,
//                 Description = asset.Description,
//                 RetailPrice = asset.RetailValue,
//                 OwnerName = "Owner Name Placeholder", // Replace with actual owner retrieval logic
//                 Status = asset.Status.ToString()
//             };
//         }
//         catch (Exception ex)
//         {
//             return Error.InternalServerError(ex.Message);
//         }
//     }

//     public async Task<Result<List<AssetResponse>>> GetAllAssetsByUserIdAsync(int userId)
//     {
//         try
//         {
//             // Validate userId
//             if (userId <= 0)
//             {
//                 return Error.BadRequest("User ID must be a positive integer.");
//             }

//             var assets = await _appUnitOfWork.AssetRepository.GetAssetsByUserIdAsync(userId);
//             if (assets == null || !assets.Any())
//             {
//                 return Error.NotFound("No assets found for the given user.");
//             }

//             return assets.Select(asset => new AssetResponse
//             {
//                 AssetId = asset.Id,
//                 Title = asset.Title,
//                 Description = asset.Description,
//                 RetailPrice = asset.RetailValue,
//                 OwnerName = "Owner Name Placeholder", // Replace with actual owner retrieval logic
//                 Status = asset.Status.ToString()
//             }).ToList();
//         }
//         catch (Exception ex)
//         {
//             return Error.InternalServerError(ex.Message);
//         }
//     }
// }

using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Common.Validation;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using System.Security.Claims;
using TheAuctionHouse.Data.EFCore.SQLite;

namespace TheAuctionHouse.Domain.Services;

public class AssetService : IAssetService
{
    private readonly IAppUnitOfWork _appUnitOfWork;
    private readonly SQLiteAppDbContext _dbContext;


    public AssetService(IAppUnitOfWork appUnitOfWork, SQLiteAppDbContext dbContext)
    {
        _appUnitOfWork = appUnitOfWork;
        _dbContext = dbContext;

    }

    public async Task<Result<bool>> CreateAssetAsync(AssetInformationUpdateRequest createAssetRequest)
    {
        try
        {
            // Validate request
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(createAssetRequest, validationError))
            {
                return validationError;
            }

            // Additional validation
            if (createAssetRequest.Title.Length < 10 || createAssetRequest.Title.Length > 150)
            {
                return Error.BadRequest("Title must be between 10-150 characters.");
            }

            if (createAssetRequest.Description.Length < 10 || createAssetRequest.Description.Length > 1000)
            {
                return Error.BadRequest("Description must be between 10-1000 characters.");
            }

            if (createAssetRequest.RetailPrice <= 0)
            {
                return Error.BadRequest("Retail price must be a positive value.");
            }

            // Extract user ID from thread principal
            var userIdClaim = Thread.CurrentPrincipal?.Identity as ClaimsIdentity;
            var userIdValue = userIdClaim?.FindFirst("userId")?.Value;
            if (string.IsNullOrEmpty(userIdValue) || !int.TryParse(userIdValue, out int userId))
            {
                //return Error.Unauthorized("Invalid or missing user token.");
                return new Error(401, "Invalid or missing user token.");

            }

            // Create new asset
            var newAsset = new Asset
            {
                Title = createAssetRequest.Title.Trim(),
                Description = createAssetRequest.Description.Trim(),
                RetailValue = createAssetRequest.RetailPrice,
                Status = AssetStatus.Draft,
                UserId = userId
            };

            await _appUnitOfWork.AssetRepository.AddAsync(newAsset);
            await _appUnitOfWork.SaveChangesAsync();

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    // public async Task<Result<bool>> UpdateAssetAsync(AssetInformationUpdateRequest updateAssetRequest)
    // {
    //     try
    //     {
    //         // Validate request
    //         Error validationError = Error.ValidationFailures();
    //         if (!ValidationHelper.Validate(updateAssetRequest, validationError))
    //         {
    //             return validationError;
    //         }

    //         // Get existing asset
    //         var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(updateAssetRequest.RetailPrice);
    //         if (asset == null)
    //         {
    //             return Error.NotFound("Asset not found.");
    //         }

    //         // Check if asset is in draft status
    //         if (asset.Status != AssetStatus.Draft)
    //         {
    //             return Error.BadRequest("Only draft assets can be updated.");
    //         }

    //         // Additional validation
    //         if (updateAssetRequest.Title.Length < 10 || updateAssetRequest.Title.Length > 150)
    //         {
    //             return Error.BadRequest("Title must be between 10-150 characters.");
    //         }

    //         if (updateAssetRequest.Description.Length < 10 || updateAssetRequest.Description.Length > 1000)
    //         {
    //             return Error.BadRequest("Description must be between 10-1000 characters.");
    //         }

    //         if (updateAssetRequest.RetailPrice <= 0)
    //         {
    //             return Error.BadRequest("Retail price must be a positive value.");
    //         }

    //         // Update asset
    //         asset.Title = updateAssetRequest.Title.Trim();
    //         asset.Description = updateAssetRequest.Description.Trim();
    //         asset.RetailValue = updateAssetRequest.RetailPrice;

    //         await _appUnitOfWork.AssetRepository.UpdateAsync(asset);
    //         await _appUnitOfWork.SaveChangesAsync();

    //         return true;
    //     }
    //     catch (Exception ex)
    //     {
    //         return Error.InternalServerError(ex.Message);
    //     }
    // }

    public async Task<Result<bool>> UpdateAssetAsync(AssetInformationUpdateRequest updateAssetRequest)
    {
        try
        {
            // Validate request
            Error validationError = Error.ValidationFailures();
            if (!ValidationHelper.Validate(updateAssetRequest, validationError))
            {
                return validationError;
            }

            // Get user ID from claims
            var claimsPrincipal = Thread.CurrentPrincipal as ClaimsPrincipal;
            if (claimsPrincipal == null)
            {
                return new Error(401, "Invalid or missing user token.");
            }

            var userIdClaim = claimsPrincipal.FindFirst("userId");
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out int userId))
            {
                return new Error(401, "Invalid or missing user token.");
            }

            // Get all draft assets for this user
            var userAssets = await _appUnitOfWork.AssetRepository.GetAssetsByUserIdAsync(userId);
            var draftAssets = userAssets.Where(a => a.Status == AssetStatus.Draft).ToList();

            if (!draftAssets.Any())
            {
                return Error.NotFound("No draft assets found for the current user.");
            }

            // Find the asset that best matches the update request
            var assetToUpdate = draftAssets
                .OrderByDescending(a => a.Id) // Prefer newer assets
                .FirstOrDefault(a =>
                    a.Title.Equals(updateAssetRequest.Title, StringComparison.OrdinalIgnoreCase) &&
                    a.Description.Equals(updateAssetRequest.Description, StringComparison.OrdinalIgnoreCase));

            if (assetToUpdate == null)
            {
                return Error.NotFound("No matching draft asset found with the provided details.");
            }

            // Additional validation
            if (updateAssetRequest.Title.Length < 10 || updateAssetRequest.Title.Length > 150)
            {
                return Error.BadRequest("Title must be between 10-150 characters.");
            }

            if (updateAssetRequest.Description.Length < 10 || updateAssetRequest.Description.Length > 1000)
            {
                return Error.BadRequest("Description must be between 10-1000 characters.");
            }

            if (updateAssetRequest.RetailPrice <= 0)
            {
                return Error.BadRequest("Retail price must be a positive value.");
            }

            // Update asset
            assetToUpdate.Title = updateAssetRequest.Title.Trim();
            assetToUpdate.Description = updateAssetRequest.Description.Trim();
            assetToUpdate.RetailValue = updateAssetRequest.RetailPrice;

            await _appUnitOfWork.AssetRepository.UpdateAsync(assetToUpdate);
            await _appUnitOfWork.SaveChangesAsync();

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<bool>> DeleteAssetAsync(int assetId)
    {
        try
        {
            // Validate assetId
            if (assetId <= 0)
            {
                return Error.BadRequest("Asset ID must be a positive integer.");
            }

            var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(assetId);
            if (asset == null)
            {
                return Error.NotFound("Asset not found.");
            }

            // Check if asset is in draft or open status
            if (asset.Status != AssetStatus.Draft && asset.Status != AssetStatus.OpenToAuction)
            {
                return Error.BadRequest("Only draft or open assets can be deleted.");
            }

            await _appUnitOfWork.AssetRepository.DeleteAsync(asset);
            await _appUnitOfWork.SaveChangesAsync();

            return true;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }

    public async Task<Result<AssetResponse>> GetAssetByIdAsync(int assetId)
    {
        try
        {
            // Validate assetId
            if (assetId <= 0)
            {
                return Error.BadRequest("Asset ID must be a positive integer.");
            }

            var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(assetId);
            if (asset == null)
            {
                return Error.NotFound("Asset not found.");
            }

            // ✅ Only fetch user if asset is valid
            var user = await _dbContext.PortalUsers.FindAsync(asset.UserId);

            return new AssetResponse
            {
                AssetId = asset.Id,
                Title = asset.Title,
                Description = asset.Description,
                RetailPrice = asset.RetailValue,
                OwnerName = user?.Name ?? "Unknown",
                Status = asset.Status.ToString()
            };
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }



    public async Task<Result<List<AssetResponse>>> GetAllAssetsByUserIdAsync(int userId)
    {
        try
        {
            if (userId <= 0)
                return Error.BadRequest("User ID must be a positive integer.");

            var assets = await _appUnitOfWork.AssetRepository.GetAssetsByUserIdAsync(userId);
            if (assets == null || !assets.Any())
                return Error.NotFound("No assets found for the given user.");

            var responses = new List<AssetResponse>();

            foreach (var asset in assets)
            {
                var user = await _dbContext.PortalUsers.FindAsync(asset.UserId);

                responses.Add(new AssetResponse
                {
                    AssetId = asset.Id,
                    Title = asset.Title,
                    Description = asset.Description,
                    RetailPrice = asset.RetailValue,
                    OwnerName = user?.Name ?? "Unknown",
                    Status = asset.Status.ToString()
                });
            }

            return responses;
        }
        catch (Exception ex)
        {
            return Error.InternalServerError(ex.Message);
        }
    }
   public async Task<Result<bool>> ChangeAssetStatusAsync(int assetId, string newStatus)
{
    try
    {
        if (!Enum.TryParse<AssetStatus>(newStatus, out var status))
        {
            return Error.BadRequest("Invalid status value");
        }

        var asset = await _appUnitOfWork.AssetRepository.GetByIdAsync(assetId);
        if (asset == null) return Error.NotFound("Asset not found");

        asset.Status = status;
        await _appUnitOfWork.AssetRepository.UpdateAsync(asset);
        await _appUnitOfWork.SaveChangesAsync();

        return true;
    }
    catch (Exception ex)
    {
        return Error.InternalServerError(ex.Message);
    }
}
}
