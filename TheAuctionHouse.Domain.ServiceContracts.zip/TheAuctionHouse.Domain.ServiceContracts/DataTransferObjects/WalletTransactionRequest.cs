public class WalletTransactionRequest
{
    public int UserId { get; set; }
    public int Amount { get; set; }
}