

// public class ChangeAssetStatusRequest
// {
//     public AssetStatus NewStatus { get; set; }
// }