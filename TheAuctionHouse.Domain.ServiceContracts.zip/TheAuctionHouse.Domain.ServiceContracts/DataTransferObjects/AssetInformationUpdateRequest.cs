using System.ComponentModel.DataAnnotations;

    public class AssetInformationUpdateRequest
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int RetailPrice { get; set; }
    }
//using System.ComponentModel.DataAnnotations;

// public class AssetInformationUpdateRequest
// {
//     public int AssetId { get; set; }  // Required for update

//     [Required]
//     public int UserId { get; set; }
//     public string Title { get; set; } = string.Empty;
//     public string Description { get; set; } = string.Empty;
//     public int RetailPrice { get; set; }
//          [Required]
//     [Range(1, 999999)]
//     public int RetailValue { get; set; }
//     }