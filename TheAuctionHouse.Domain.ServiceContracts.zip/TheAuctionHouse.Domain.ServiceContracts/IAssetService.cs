using TheAuctionHouse.Common.ErrorHandling;
public interface IAssetService
{
  Task<Result<bool>> CreateAssetAsync(AssetInformationUpdateRequest createAssetRequest);
  Task<Result<bool>> UpdateAssetAsync(AssetInformationUpdateRequest updateAssetRequest);
  Task<Result<bool>> DeleteAssetAsync(int assetId);
  Task<Result<AssetResponse>> GetAssetByIdAsync(int assetId);
  Task<Result<List<AssetResponse>>> GetAllAssetsByUserIdAsync(int userId);
  Task<Result<bool>> ChangeAssetStatusAsync(int assetId, string newStatus);

}