using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Domain.Entities;

namespace TheAuctionHouse.Data.EFCore.SQLite
{
    public interface IAppDbContext
    {
        DbSet<T>? GetDbSet<T>() where T : class;
        DbSet<PortalUser> PortalUsers { get; set; }
        DbSet<Asset> Assets { get; set; }
        DbSet<Auction> Auctions { get; set; }
        DbSet<BidHistory> BidHistories { get; set; }

        // Queryable versions for LINQ support
        IQueryable<PortalUser> PortalUsersQuery { get; }
        IQueryable<Asset> AssetsQuery { get; }
        IQueryable<Auction> AuctionsQuery { get; }
        IQueryable<BidHistory> BidHistoriesQuery { get; }

        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}