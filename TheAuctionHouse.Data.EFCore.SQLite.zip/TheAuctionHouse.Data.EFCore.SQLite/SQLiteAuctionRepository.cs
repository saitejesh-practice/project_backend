// SQLiteAuctionRepository.cs
using TheAuctionHouse.Data.EFCore.SQLite;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;
using Microsoft.EntityFrameworkCore;
public class SQLiteAuctionRepository : GenericRepository<Auction>, IAuctionRepository
{
    public SQLiteAuctionRepository(IAppDbContext context) : base(context) { }

    public async Task<List<Auction>> GetAuctionsByUserIdAsync(int userId)
    {
        return await _context.Auctions
            .Where(a => a.UserId == userId)
            .ToListAsync();
    }

    public async Task<List<BidHistory>> GetBidHistoriesByAuctionIdAsync(int auctionId)
    {
        return await _context.BidHistories
            .Where(b => b.AuctionId == auctionId)
            .ToListAsync();
    }

    public async Task<List<BidHistory>> GetBidHistoriesByUserIdAsync(int userId)
    {
        return await _context.BidHistories
            .Where(b => b.BidderId == userId)
            .ToListAsync();
    }
}