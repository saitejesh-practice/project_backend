// using Microsoft.EntityFrameworkCore;
// using TheAuctionHouse.Domain.Entities;
// using System.Linq;


// namespace TheAuctionHouse.Data.EFCore.SQLite
// {
//     public class SQLiteAppDbContext : DbContext, IAppDbContext
//     {
//         public SQLiteAppDbContext(DbContextOptions<SQLiteAppDbContext> options) : base(options) { }

//         public DbSet<PortalUser> PortalUsers { get; set; }
//         public DbSet<Asset> Assets { get; set; }
//         public DbSet<Auction> Auctions { get; set; }
//         public DbSet<BidHistory> BidHistories { get; set; }

//         public DbSet<T>? GetDbSet<T>() where T : class
//         {
//             return Set<T>();
//         }

//         protected override void OnModelCreating(ModelBuilder modelBuilder)
//         {
//             modelBuilder.Entity<Asset>()
//                 .Property(a => a.RetailValue)
//                 .HasColumnType("decimal(18,2)");

//             modelBuilder.Entity<Auction>()
//                 .Property(a => a.ReservedPrice)
//                 .HasColumnType("decimal(18,2)");

//             modelBuilder.Entity<Auction>()
//                 .Property(a => a.CurrentHighestBid)
//                 .HasColumnType("decimal(18,2)");

//             modelBuilder.Entity<BidHistory>()
//                 .Property(b => b.BidAmount)
//                 .HasColumnType("decimal(18,2)");

//             base.OnModelCreating(modelBuilder);
//         }
//     }
// }

using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Data.EFCore.SQLite;

namespace TheAuctionHouse.Data.EFCore.SQLite
{
    public class SQLiteAppDbContext : DbContext, IAppDbContext
    {
        public SQLiteAppDbContext(DbContextOptions<SQLiteAppDbContext> options) 
            : base(options) { }

        public DbSet<PortalUser> PortalUsers { get; set; }
        public DbSet<Asset> Assets { get; set; }
        public DbSet<Auction> Auctions { get; set; }
        public DbSet<BidHistory> BidHistories { get; set; }

        // Explicit interface implementation for queryables
        IQueryable<PortalUser> IAppDbContext.PortalUsersQuery => PortalUsers.AsQueryable();
        IQueryable<Asset> IAppDbContext.AssetsQuery => Assets.AsQueryable();
        IQueryable<Auction> IAppDbContext.AuctionsQuery => Auctions.AsQueryable();
        IQueryable<BidHistory> IAppDbContext.BidHistoriesQuery => BidHistories.AsQueryable();

        public DbSet<T>? GetDbSet<T>() where T : class => Set<T>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure decimal precision for all monetary values
            modelBuilder.Entity<Asset>()
                .Property(a => a.RetailValue)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Auction>()
                .Property(a => a.ReservedPrice)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Auction>()
                .Property(a => a.CurrentHighestBid)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Auction>()
                .Property(a => a.MinimumBidIncrement)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<BidHistory>()
                .Property(b => b.BidAmount)
                .HasColumnType("decimal(18,2)");

            // // Configure relationships
            // modelBuilder.Entity<Auction>()
            //     .HasOne(a => a.Asset)
            //     .WithMany()
            //     .HasForeignKey(a => a.AssetId)
            //     .OnDelete(DeleteBehavior.Restrict);

            // modelBuilder.Entity<BidHistory>()
            //     .HasOne(b => b.Auction)
            //     .WithMany()
            //     .HasForeignKey(b => b.AuctionId)
            //     .OnDelete(DeleteBehavior.Cascade);
             // Configure relationships explicitly without navigation properties
    modelBuilder.Entity<Auction>()
        .HasOne<Asset>() // Specify the related entity type
        .WithMany() // No navigation property in Asset
        .HasForeignKey(a => a.AssetId) // Foreign key in Auction
        .OnDelete(DeleteBehavior.Restrict);

    modelBuilder.Entity<BidHistory>()
        .HasOne<Auction>() // Specify the related entity type
        .WithMany() // No navigation property in Auction
        .HasForeignKey(b => b.AuctionId) // Foreign key in BidHistory
        .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}