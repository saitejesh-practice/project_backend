// public class SQLiteAssetRepository : GenericRepository<Asset>, IAssetRepository
// {
//     public SQLiteAssetRepository(IAppDbContext context) : base(context) { }

//     public async Task<List<Asset>> GetAssetsByUserIdAsync(int userId)
//     {
//         return await _context.Assets
//             .Where(a => a.UserId == userId)
//             .ToListAsync();
//     }
// }

using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.SQLite;
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;

namespace TheAuctionHouse.Data.EFCore.SQLite
{
    public class SQLiteAssetRepository : GenericRepository<Asset>, IAssetRepository
    {
        private readonly new IAppDbContext _context;

        public SQLiteAssetRepository(IAppDbContext context) : base(context) 
        {
            _context = context;
        }

        public async Task<List<Asset>> GetAssetsByUserIdAsync(int userId)
        {
            return await _context.AssetsQuery
                .Where(a => a.UserId == userId)
                .OrderByDescending(a => a.Id)
                .ToListAsync();
        }
    }
}