﻿using Microsoft.EntityFrameworkCore;
using TheAuctionHouse.Data.EFCore.SQLite;
using TheAuctionHouse.Domain.DataContracts;

namespace TheAuctionHouse.Data.EFCore.SQLite
{
    public class GenericRepository<T> : IRepository<T> where T : class
    {
        protected readonly SQLiteAppDbContext _context;
        protected readonly DbSet<T> _dbSet;

        public GenericRepository(IAppDbContext context)
        {
            if (context is not SQLiteAppDbContext)
                throw new ArgumentException("Invalid context type. Expected SQLiteAppDbContext.");
            
            _context = (SQLiteAppDbContext)context;
            _dbSet = _context.Set<T>();
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        public virtual async Task<T?> GetByIdAsync(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        public virtual async Task AddAsync(T entity)
        {
            await _dbSet.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public virtual async Task UpdateAsync(T entity)
        {
            _dbSet.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public virtual async Task DeleteAsync(int id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public virtual async Task DeleteAsync(T entity)
        {
            _dbSet.Remove(entity);
            await _context.SaveChangesAsync();
        }

        public virtual async Task<IEnumerable<T>> FindAsync(Func<T, bool> predicate)
        {
            return await Task.FromResult(_dbSet.Where(predicate).ToList());
        }
    }
}