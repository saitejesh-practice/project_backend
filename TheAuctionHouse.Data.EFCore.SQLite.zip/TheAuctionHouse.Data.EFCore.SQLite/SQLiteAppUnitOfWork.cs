
using TheAuctionHouse.Domain.DataContracts;
using TheAuctionHouse.Domain.Entities;

namespace TheAuctionHouse.Data.EFCore.SQLite
{
    public class SQLiteAppUnitOfWork : IAppUnitOfWork
    {
        private readonly SQLiteAppDbContext _context;
        private bool _disposed;

        public SQLiteAppUnitOfWork(SQLiteAppDbContext context)
        {
            _context = context;
            PortalUserRepository = new SQLitePortalUserRepository(_context);
            AssetRepository = new SQLiteAssetRepository(_context);
            AuctionRepository = new SQLiteAuctionRepository(_context);
        }

        public IPortalUserRepository PortalUserRepository { get; }
        public IAssetRepository AssetRepository { get; }
        public IAuctionRepository AuctionRepository { get; }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed && disposing)
            {
                _context.Dispose();
            }
            _disposed = true;
        }
    }
}