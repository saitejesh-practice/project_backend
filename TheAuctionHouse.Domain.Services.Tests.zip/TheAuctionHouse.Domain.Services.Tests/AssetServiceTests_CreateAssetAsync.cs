using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Moq;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using Xunit;

namespace TheAuctionHouse.Domain.Services.Tests;

public class AssetServiceTests_CreateAssetAsync
{
    private IAppUnitOfWork GetInMemoryAppUnitOfWork()
    {
        var options = new DbContextOptionsBuilder<InMemoryAppDbContext>()
            .UseInMemoryDatabase(System.Guid.NewGuid().ToString())
            .Options;
        var context = new InMemoryAppDbContext(options);
        return new InMemoryAppUnitOfWork(context);
    }

    [Fact]
    public async Task CreateAssetAsync_ShouldSucceed_WhenRequestIsValid()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        var assetService = new AssetService(appUnitOfWork);

        var createRequest = new AssetInformationUpdateRequest
        {
            Title = "A valid asset title",
            Description = "A valid asset description for testing.",
            RetailPrice = 1000
        };

        // Act
        var result = await assetService.CreateAssetAsync(createRequest);

        // Assert
        Assert.True(result.IsSuccess);
        var assets = await appUnitOfWork.AssetRepository.GetAllAsync();
        Assert.Single(assets);
        Assert.Equal("A valid asset title", assets.First().Title);
    }

    [Fact]
    public async Task CreateAssetAsync_ShouldFail_WhenTitleIsTooShort()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        var assetService = new AssetService(appUnitOfWork);

        var createRequest = new AssetInformationUpdateRequest
        {
            Title = "Short",
            Description = "A valid asset description for testing.",
            RetailPrice = 1000
        };

        // Act
        var result = await assetService.CreateAssetAsync(createRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("Title must be between 10-150 characters.", result.Error.Message);
    }

    [Fact]
    public async Task CreateAssetAsync_ShouldFail_WhenDescriptionIsTooShort()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        var assetService = new AssetService(appUnitOfWork);

        var createRequest = new AssetInformationUpdateRequest
        {
            Title = "A valid asset title",
            Description = "Short",
            RetailPrice = 1000
        };

        // Act
        var result = await assetService.CreateAssetAsync(createRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("Description must be between 10-1000 characters.", result.Error.Message);
    }

    [Fact]
    public async Task CreateAssetAsync_ShouldFail_WhenRetailPriceIsNotPositive()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        var assetService = new AssetService(appUnitOfWork);

        var createRequest = new AssetInformationUpdateRequest
        {
            Title = "A valid asset title",
            Description = "A valid asset description for testing.",
            RetailPrice = 0
        };

        // Act
        var result = await assetService.CreateAssetAsync(createRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("Retail price must be a positive value.", result.Error.Message);
    }
        [Fact]
    public async Task CreateAssetAsync_ShouldFail_WhenTitleOrDescriptionIsWhitespace()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        var assetService = new AssetService(appUnitOfWork);
    
        var createRequest = new AssetInformationUpdateRequest
        {
            Title = "        ", // Only spaces
            Description = "      ", // Only spaces
            RetailPrice = 1000
        };
    
        // Act
        var result = await assetService.CreateAssetAsync(createRequest);
    
        // Assert
        Assert.False(result.IsSuccess);
        // The error could be from validation or your manual checks, so check for 400 or 422
        Assert.True(result.Error.ErrorCode == 400 || result.Error.ErrorCode == 422);
    }
}