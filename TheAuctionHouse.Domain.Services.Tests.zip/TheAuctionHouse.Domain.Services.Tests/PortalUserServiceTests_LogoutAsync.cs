using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moq;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using Xunit;

namespace TheAuctionHouse.Domain.Services.Tests;

public class PortalUserServiceTests_LogoutAsync
{
    private IAppUnitOfWork GetInMemoryAppUnitOfWork()
    {
        var options = new DbContextOptionsBuilder<InMemoryAppDbContext>()
            .UseInMemoryDatabase(System.Guid.NewGuid().ToString())
            .Options;
        var context = new InMemoryAppDbContext(options);
        return new InMemoryAppUnitOfWork(context);
    }

    [Fact]
    public async Task LogoutAsync_ShouldReturnTrue_WhenUserIdIsValid()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var user = new PortalUser
        {
            Id = 1,
            Name = "Test User",
            EmailId = "testuser@domain.com",
            HashedPassword = "hashed"
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        // Act
        var result = await portalUserService.LogoutAsync(1);

        // Assert
        Assert.True(result.IsSuccess);
    }

    [Fact]
    public async Task LogoutAsync_ShouldFail_WhenUserIdIsInvalid()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        // Act
        var result = await portalUserService.LogoutAsync(0);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode); // BadRequest
        Assert.Equal("Invalid user ID", result.Error.Message);
    }

    [Fact]
    public async Task LogoutAsync_ShouldFail_WhenUserDoesNotExist()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        // Act
        var result = await portalUserService.LogoutAsync(999);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Error.ErrorCode); // NotFound
        Assert.Equal("User not found", result.Error.Message);
    }
}