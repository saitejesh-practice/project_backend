using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moq;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using Xunit;

namespace TheAuctionHouse.Domain.Services.Tests;

public class PortalUserServiceTests_ResetPasswordAsync
{
    private IAppUnitOfWork GetInMemoryAppUnitOfWork()
    {
        var options = new DbContextOptionsBuilder<InMemoryAppDbContext>()
            .UseInMemoryDatabase(System.Guid.NewGuid().ToString())
            .Options;
        var context = new InMemoryAppDbContext(options);
        return new InMemoryAppUnitOfWork(context);
    }

        [Fact]
    public async Task ResetPasswordAsync_ShouldSucceed_WhenAllDataIsValid()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();
        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);
    
        // Use the same hashing logic as the service for the initial password
        var initialHashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("OldPassword123"));
    
        var user = new PortalUser
        {
            Id = 1,
            Name = "Test User",
            EmailId = "testuser@domain.com",
            HashedPassword = initialHashedPassword
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();
    
        var resetRequest = new ResetPasswordRequest
        {
            UserId = 1,
            OldPassword = "OldPassword123",
            NewPassword = "NewPassword456",
            ConfirmPassword = "NewPassword456"
        };
    
        // Act
        var result = await portalUserService.ResetPasswordAsync(resetRequest);
    
        // Assert
        Assert.True(result.IsSuccess);
    
        var updatedUser = await appUnitOfWork.PortalUserRepository.GetUserByUserIdAsync(1);
        Assert.NotNull(updatedUser);
        Assert.NotEqual(initialHashedPassword, updatedUser.HashedPassword);
        // Optionally, verify the new password matches
        var newHashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("NewPassword456"));
        Assert.Equal(newHashedPassword, updatedUser.HashedPassword);
    }

    [Fact]
    public async Task ResetPasswordAsync_ShouldFail_WhenUserNotFound()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var resetRequest = new ResetPasswordRequest
        {
            UserId = 999,
            OldPassword = "OldPassword123",
            NewPassword = "NewPassword456",
            ConfirmPassword = "NewPassword456"
        };

        // Act
        var result = await portalUserService.ResetPasswordAsync(resetRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Error.ErrorCode);
        Assert.Equal("User not found", result.Error.Message);
    }

    [Fact]
    public async Task ResetPasswordAsync_ShouldFail_WhenOldPasswordIsIncorrect()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var user = new PortalUser
        {
            Id = 2,
            Name = "Test User",
            EmailId = "testuser2@domain.com",
            HashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("CorrectOldPassword"))
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var resetRequest = new ResetPasswordRequest
        {
            UserId = 2,
            OldPassword = "WrongOldPassword",
            NewPassword = "NewPassword456",
            ConfirmPassword = "NewPassword456"
        };

        // Act
        var result = await portalUserService.ResetPasswordAsync(resetRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("Current password is incorrect", result.Error.Message);
    }

    [Fact]
    public async Task ResetPasswordAsync_ShouldFail_WhenNewPasswordsDoNotMatch()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var user = new PortalUser
        {
            Id = 3,
            Name = "Test User",
            EmailId = "testuser3@domain.com",
            HashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("OldPassword123"))
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var resetRequest = new ResetPasswordRequest
        {
            UserId = 3,
            OldPassword = "OldPassword123",
            NewPassword = "NewPassword456",
            ConfirmPassword = "DifferentPassword"
        };

        // Act
        var result = await portalUserService.ResetPasswordAsync(resetRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("New passwords don't match", result.Error.Message);
    }

    [Fact]
    public async Task ResetPasswordAsync_ShouldFail_WhenValidationFails()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var resetRequest = new ResetPasswordRequest
        {
            UserId = 0, // Invalid user id
            OldPassword = "",
            NewPassword = "",
            ConfirmPassword = ""
        };

        // Act
        var result = await portalUserService.ResetPasswordAsync(resetRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
}