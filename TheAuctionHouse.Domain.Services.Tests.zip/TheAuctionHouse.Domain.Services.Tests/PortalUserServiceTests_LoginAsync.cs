using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moq;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using Xunit;

namespace TheAuctionHouse.Domain.Services.Tests;

public class PortalUserServiceTests_LoginAsync
{
    private IAppUnitOfWork GetInMemoryAppUnitOfWork()
    {
        var options = new DbContextOptionsBuilder<InMemoryAppDbContext>()
            .UseInMemoryDatabase(System.Guid.NewGuid().ToString())
            .Options;
        var context = new InMemoryAppDbContext(options);
        return new InMemoryAppUnitOfWork(context);
    }

    [Fact]
    public async Task LoginAsync_ShouldReturnToken_WhenCredentialsAreValid()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();
        string expectedToken = "mocked-jwt-token";
        jwtTokenServiceMock.Setup(j => j.GenerateToken(It.IsAny<int>(), It.IsAny<string>())).Returns(expectedToken);

        var user = new PortalUser
        {
            Name = "Test User",
            EmailId = "testuser@domain.com",
            HashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("TestPassword123"))
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var loginRequest = new LoginRequest
        {
            EmailId = "testuser@domain.com",
            Password = "TestPassword123"
        };

        // Act
        Result<string> result = await portalUserService.LoginAsync(loginRequest);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(expectedToken, result.Value);
    }

    [Fact]
    public async Task LoginAsync_ShouldFail_WhenUserNotFound()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var loginRequest = new LoginRequest
        {
            EmailId = "notfound@domain.com",
            Password = "AnyPassword"
        };

        // Act
        Result<string> result = await portalUserService.LoginAsync(loginRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Error.ErrorCode);
        Assert.Equal("User not found", result.Error.Message);
    }

    [Fact]
    public async Task LoginAsync_ShouldFail_WhenPasswordIsIncorrect()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var user = new PortalUser
        {
            Name = "Test User",
            EmailId = "testuser@domain.com",
            HashedPassword = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("CorrectPassword"))
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(user);
        await appUnitOfWork.SaveChangesAsync();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var loginRequest = new LoginRequest
        {
            EmailId = "testuser@domain.com",
            Password = "WrongPassword"
        };

        // Act
        Result<string> result = await portalUserService.LoginAsync(loginRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode);
        Assert.Equal("Invalid credentials", result.Error.Message);
    }

    [Fact]
    public async Task LoginAsync_ShouldFail_WhenValidationFails()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var loginRequest = new LoginRequest
        {
            EmailId = "", // Missing email
            Password = "" // Missing password
        };

        // Act
        Result<string> result = await portalUserService.LoginAsync(loginRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
}