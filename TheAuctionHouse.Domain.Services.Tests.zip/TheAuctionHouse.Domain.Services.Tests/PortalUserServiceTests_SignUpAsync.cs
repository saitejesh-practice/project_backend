using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moq;
using TheAuctionHouse.Common.ErrorHandling;
using TheAuctionHouse.Data.EFCore.InMemory;
using TheAuctionHouse.Domain.Entities;
using TheAuctionHouse.Domain.ServiceContracts;
using Xunit;

namespace TheAuctionHouse.Domain.Services.Tests;

public class PortalUserServiceTests_SignUpAsync
{
    private IAppUnitOfWork GetInMemoryAppUnitOfWork()
    {
        var options = new DbContextOptionsBuilder<InMemoryAppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        var context = new InMemoryAppDbContext(options);
        return new InMemoryAppUnitOfWork(context);
    }

    [Fact]
    public async Task SignUpAsync_ShouldCreateNewUser_WhenValidRequest()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var signUpRequest = new SignUpRequest
        {
            Name = "Test User",
            EmailId = "testuser@domain.com",
            Password = "TestPassword123"
        };

        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);

        // Assert
        Assert.True(result.IsSuccess);

        var createdUser = await appUnitOfWork.PortalUserRepository.GetUserByEmailAsync(signUpRequest.EmailId);
        Assert.NotNull(createdUser);
        Assert.Equal(signUpRequest.Name, createdUser.Name);
        Assert.Equal(signUpRequest.EmailId, createdUser.EmailId);
    }

    [Fact]
    public async Task SignUpAsync_ShouldFail_WhenEmailAlreadyExists()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        var existingUser = new PortalUser
        {
            Name = "Existing User",
            EmailId = "existinguser@domain.com",
            HashedPassword = "ExistingPassword"
        };
        await appUnitOfWork.PortalUserRepository.AddAsync(existingUser);
        await appUnitOfWork.SaveChangesAsync();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var signUpRequest = new SignUpRequest
        {
            Name = "New User",
            EmailId = "existinguser@domain.com", // Same email as existing user
            Password = "NewPassword123"
        };

        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Error.ErrorCode); // BadRequest
        Assert.Equal("Email already registered", result.Error.Message);
    }

    [Fact]
    public async Task SignUpAsync_ShouldFail_WhenValidationFails()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var signUpRequest = new SignUpRequest
        {
            Name = "", // Invalid name
            EmailId = "invalidemail", // Invalid email format
            Password = "123" // Weak password
        };

        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
    [Fact]
    public async Task SignUpAsync_ShouldFail_WhenEmailIsEmpty()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var signUpRequest = new SignUpRequest
        {
            Name = "Test User",
            EmailId = "", // Empty email
            Password = "TestPassword123"
        };

        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
    [Fact]
    public async Task SignUpAsync_ShouldFail_WhenNoDetailsProvided()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();

        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);

        var signUpRequest = new SignUpRequest
        {
            Name = "", // Empty name
            EmailId = "", // Empty email
            Password = "" // Empty password
        };

        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
        [Fact]
    public async Task SignUpAsync_ShouldFail_WhenPasswordIsMissing()
    {
        // Arrange
        IAppUnitOfWork appUnitOfWork = GetInMemoryAppUnitOfWork();
        Mock<IEmailService> emailServiceMock = new Mock<IEmailService>();
        Mock<IJwtTokenService> jwtTokenServiceMock = new Mock<IJwtTokenService>();
    
        PortalUserService portalUserService = new PortalUserService(appUnitOfWork, emailServiceMock.Object, jwtTokenServiceMock.Object);
    
        var signUpRequest = new SignUpRequest
        {
            Name = "Test User",
            EmailId = "testuser@domain.com",
            Password = "" // Missing password
        };
    
        // Act
        Result<bool> result = await portalUserService.SignUpAsync(signUpRequest);
    
        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Error.ErrorCode); // Validation failure
    }
}